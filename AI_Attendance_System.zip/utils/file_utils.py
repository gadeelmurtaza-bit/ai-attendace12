import os
from shutil import copyfile

def save_student_image(name, img_path, save_folder='students/images'):
    if not os.path.exists(save_folder):
        os.makedirs(save_folder)
    ext = os.path.splitext(img_path)[1]
    save_path = os.path.join(save_folder, f"{name}{ext}")
    copyfile(img_path, save_path)
