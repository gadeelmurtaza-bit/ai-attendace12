import face_recognition
import os
import pandas as pd
from datetime import datetime

def load_student_images(folder_path):
    images = []
    names = []
    for filename in os.listdir(folder_path):
        if filename.endswith('.jpg') or filename.endswith('.png'):
            img = face_recognition.load_image_file(os.path.join(folder_path, filename))
            encodings = face_recognition.face_encodings(img)
            if encodings:
                images.append(encodings[0])
                names.append(os.path.splitext(filename)[0])
    return images, names

def mark_attendance(name, roll=None, attendance_file='attendance.csv'):
    now = datetime.now()
    time_str = now.strftime('%H:%M:%S')
    date_str = now.strftime('%Y-%m-%d')

    if not os.path.exists(attendance_file):
        df = pd.DataFrame(columns=['Roll', 'Name', 'Date', 'Time'])
        df.to_csv(attendance_file, index=False)

    df = pd.read_csv(attendance_file)
    if not ((df['Name'] == name) & (df['Date'] == date_str)).any():
        new_row = {'Name': name, 'Roll': roll, 'Date': date_str, 'Time': time_str}
        df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
        df.to_csv(attendance_file, index=False)
