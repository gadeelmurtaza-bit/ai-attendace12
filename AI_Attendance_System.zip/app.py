import streamlit as st
import cv2
import numpy as np
from PIL import Image
from utils.face_recognition_utils import load_student_images, mark_attendance
from utils.file_utils import save_student_image
import os
import pandas as pd

st.title("AI Attendance System")

menu = ["Home", "Register Single Student", "Register Bulk Students", "Take Attendance"]
choice = st.sidebar.selectbox("Menu", menu)

# Load known faces
known_face_encodings, known_face_names = load_student_images('students/images')

if choice == "Register Single Student":
    st.subheader("Register Single Student")
    name = st.text_input("Enter Name")
    roll = st.text_input("Enter Roll Number")
    img_file = st.file_uploader("Upload Student Photo", type=['jpg', 'png'])
    if st.button("Register"):
        if name and roll and img_file:
            img_path = f"students/images/{roll}_{name}.jpg"
            with open(img_path, "wb") as f:
                f.write(img_file.getbuffer())
            st.success(f"Student {name} registered successfully!")

elif choice == "Register Bulk Students":
    st.subheader("Bulk Registration via CSV")
    uploaded_file = st.file_uploader("Upload CSV", type=['csv'])
    if uploaded_file:
        df = pd.read_csv(uploaded_file)
        st.dataframe(df)
        if st.button("Register All"):
            for index, row in df.iterrows():
                img_path = row['PhotoPath']
                if os.path.exists(img_path):
                    save_student_image(f"{row['Roll']}_{row['Name']}", img_path)
            st.success("All students registered successfully!")

elif choice == "Take Attendance":
    st.subheader("Attendance via Camera")
    img_file_buffer = st.camera_input("Capture Photo")
    if img_file_buffer is not None:
        img = Image.open(img_file_buffer)
        rgb_frame = np.array(img)
        rgb_frame = rgb_frame[:, :, ::-1]  # RGB to BGR for OpenCV

        face_locations = cv2.face_recognition.face_locations(rgb_frame)
        face_encodings = cv2.face_recognition.face_encodings(rgb_frame, face_locations)

        for face_encoding, face_location in zip(face_encodings, face_locations):
            matches = cv2.face_recognition.compare_faces(known_face_encodings, face_encoding)
            name = "Unknown"
            roll = None

            face_distances = cv2.face_recognition.face_distance(known_face_encodings, face_encoding)
            best_match_index = np.argmin(face_distances)
            if matches[best_match_index]:
                name = known_face_names[best_match_index]
                if "_" in name:
                    roll = name.split("_")[0]
                    name = name.split("_")[1]
                mark_attendance(name, roll)

        st.image(img, caption="Captured Image", use_column_width=True)
        st.success("Attendance marked for detected students!")
